def run():
    import pytest
    pytest.main()


if __name__ == "__main__":
    run()
