class BackendSystem:
    def get_record_by_internal_id(self, internal_id):
        raise NotImplementedError
