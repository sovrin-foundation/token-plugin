
class NonceNotFound(RuntimeError):
    pass


class SignatureRejected(RuntimeError):
    pass
