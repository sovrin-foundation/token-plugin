from indy_client import test

test.run()
