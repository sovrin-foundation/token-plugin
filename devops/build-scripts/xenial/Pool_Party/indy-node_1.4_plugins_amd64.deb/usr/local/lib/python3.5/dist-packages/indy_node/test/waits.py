

def expectedUpgradeScheduled():
    return 5


def expectedNoUpgradeScheduled():
    return 10
