from sovtoken.test.demo.run_demo import run_demo

run_demo('./plenum/server/plugin/sovtoken/test/test_demo.py')
