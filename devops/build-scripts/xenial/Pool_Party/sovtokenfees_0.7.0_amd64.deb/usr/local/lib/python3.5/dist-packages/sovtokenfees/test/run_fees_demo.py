from sovtoken.test.demo.run_demo import run_demo

run_demo('./plenum/server/plugin/sovtokenfees/test/test_demo.py')
